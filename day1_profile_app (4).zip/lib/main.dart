import 'package:flutter/material.dart';

void main() {
  runApp(const Day3App());
}

class Day3App extends StatelessWidget {
  const Day3App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Day 3 Task Manager',
      theme: ThemeData(
        primarySwatch: Colors.purple,
      ),
      home: const TaskHomePage(),
    );
  }
}

class Task {
  String title;
  bool done;

  Task({
    required this.title,
    required this.done,
  });
}

class TaskHomePage extends StatefulWidget {
  const TaskHomePage({super.key});

  @override
  State<TaskHomePage> createState() => _TaskHomePageState();
}

class _TaskHomePageState extends State<TaskHomePage> {
  final TextEditingController taskController = TextEditingController();

  List<Task> tasks = [
    Task(title: "Learn setState", done: false),
    Task(title: "Practice navigation", done: false),
  ];

  void addTask() {
    final taskTitle = taskController.text.trim();

    if (taskTitle.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Please write a task title."),
        ),
      );
      return;
    }

    setState(() {
      tasks.add(Task(title: taskTitle, done: false));
      taskController.clear();
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("Task added successfully."),
      ),
    );
  }

  void deleteTask(int index) {
    setState(() {
      tasks.removeAt(index);
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("Task deleted."),
      ),
    );
  }

  void toggleDone(int index) {
    setState(() {
      tasks[index].done = !tasks[index].done;
    });
  }

  void openDetails(Task task) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => TaskDetailsPage(task: task),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.purple[50],
      appBar: AppBar(
        title: const Text("Day 3 - Task Manager"),
        centerTitle: true,
        backgroundColor: Colors.purple,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: taskController,
              decoration: const InputDecoration(
                labelText: "Task title",
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.task),
              ),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: addTask,
              child: const Text("Add Task"),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: tasks.length,
                itemBuilder: (context, index) {
                  return Card(
                    child: ListTile(
                      leading: Checkbox(
                        value: tasks[index].done,
                        onChanged: (value) {
                          toggleDone(index);
                        },
                      ),
                      title: Text(
                        tasks[index].title,
                        style: TextStyle(
                          decoration: tasks[index].done
                              ? TextDecoration.lineThrough
                              : TextDecoration.none,
                        ),
                      ),
                      subtitle: Text(
                        tasks[index].done ? "Completed" : "Not completed",
                      ),
                      onTap: () {
                        openDetails(tasks[index]);
                      },
                      trailing: IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () {
                          deleteTask(index);
                        },
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class TaskDetailsPage extends StatelessWidget {
  final Task task;

  const TaskDetailsPage({
    super.key,
    required this.task,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Task Details"),
        backgroundColor: Colors.purple,
      ),
      body: Center(
        child: Card(
          margin: const EdgeInsets.all(25),
          child: Padding(
            padding: const EdgeInsets.all(25),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.info,
                  size: 70,
                  color: Colors.purple,
                ),
                const SizedBox(height: 15),
                Text(
                  task.title,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  task.done ? "Status: Completed" : "Status: Not completed",
                  style: const TextStyle(fontSize: 18),
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: const Text("Go Back"),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
