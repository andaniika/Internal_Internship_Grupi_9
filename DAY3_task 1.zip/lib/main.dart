import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: QuizScreen(),
    );
  }
}

/// 🔹 MODEL CLASS
class Question {
  String questionText;
  List<String> options;
  int correctIndex;

  Question({
    required this.questionText,
    required this.options,
    required this.correctIndex,
  });
}

/// 🔹 QUIZ SCREEN
class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  int currentIndex = 0;
  int score = 0;

  List<Question> questions = [
    Question(
      questionText: "What is Flutter?",
      options: ["Language", "Framework", "Database", "OS"],
      correctIndex: 1,
    ),
    Question(
      questionText: "Which language does Flutter use?",
      options: ["Java", "Kotlin", "Dart", "Swift"],
      correctIndex: 2,
    ),
    Question(
      questionText: "Who developed Flutter?",
      options: ["Apple", "Google", "Microsoft", "Meta"],
      correctIndex: 1,
    ),
    Question(
      questionText: "What is setState used for?",
      options: ["Store data", "Refresh UI", "Navigate", "Debug"],
      correctIndex: 1,
    ),
    Question(
      questionText: "Which widget displays a list?",
      options: ["Container", "Column", "ListView", "Stack"],
      correctIndex: 2,
    ),
  ];

  void answerQuestion(int selectedIndex) {
    if (selectedIndex == questions[currentIndex].correctIndex) {
      score++;
    }

    if (currentIndex < questions.length - 1) {
      setState(() {
        currentIndex++;
      });
    } else {
      /// 🔹 NAVIGATION TE RESULT SCREEN
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ResultScreen(score: score, total: questions.length),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final question = questions[currentIndex];

    return Scaffold(
      appBar: AppBar(title: const Text("Quiz App")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            /// PYETJA
            Text(
              question.questionText,
              style: const TextStyle(fontSize: 20),
            ),
            const SizedBox(height: 20),

            /// OPSIONET
            ...List.generate(question.options.length, (index) {
              return Container(
                width: double.infinity,
                margin: const EdgeInsets.symmetric(vertical: 5),
                child: ElevatedButton(
                  onPressed: () => answerQuestion(index),
                  child: Text(question.options[index]),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}

/// 🔹 RESULT SCREEN
class ResultScreen extends StatelessWidget {
  final int score;
  final int total;

  const ResultScreen({
    super.key,
    required this.score,
    required this.total,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Result")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "You scored $score / $total",
              style: const TextStyle(fontSize: 24),
            ),
            const SizedBox(height: 20),

            /// 🔹 RESTART
            ElevatedButton(
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const QuizScreen(),
                  ),
                );
              },
              child: const Text("Restart Quiz"),
            )
          ],
        ),
      ),
    );
  }
}
