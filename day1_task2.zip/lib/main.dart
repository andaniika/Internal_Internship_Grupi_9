import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: GradeCalculator(),
    );
  }
}

class GradeCalculator extends StatefulWidget {
  const GradeCalculator({super.key});

  @override
  State<GradeCalculator> createState() => _GradeCalculatorState();
}

class _GradeCalculatorState extends State<GradeCalculator> {
  final TextEditingController grade1 = TextEditingController();
  final TextEditingController grade2 = TextEditingController();
  final TextEditingController grade3 = TextEditingController();

  String result = '';
  String status = '';
  Color statusColor = Colors.black;

  void calculateAverage() {
    if (grade1.text.isEmpty || grade2.text.isEmpty || grade3.text.isEmpty) {
      setState(() {
        result = 'Plotëso të gjitha fushat!';
        status = '';
      });
      return;
    }

    double? g1 = double.tryParse(grade1.text);
    double? g2 = double.tryParse(grade2.text);
    double? g3 = double.tryParse(grade3.text);

    if (g1 == null || g2 == null || g3 == null) {
      setState(() {
        result = 'Vendos vetëm numra!';
        status = '';
      });
      return;
    }

    double avg = (g1 + g2 + g3) / 3;

    setState(() {
      result = 'Mesatarja: ${avg.toStringAsFixed(2)}';

      if (avg >= 50) {
        status = 'Kalon ✅';
        statusColor = Colors.green;
      } else {
        status = 'Duhet përmirësim ❌';
        statusColor = Colors.red;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Grade Calculator')),
      body: Center(
        child: Container(
          padding: const EdgeInsets.all(20),
          margin: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.grey[100],
            borderRadius: BorderRadius.circular(15),
            boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 10)],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: grade1,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Nota 1'),
              ),
              TextField(
                controller: grade2,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Nota 2'),
              ),
              TextField(
                controller: grade3,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Nota 3'),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: calculateAverage,
                child: const Text('Llogarit'),
              ),
              const SizedBox(height: 20),
              Text(result, style: const TextStyle(fontSize: 18)),
              Text(
                status,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: statusColor,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
